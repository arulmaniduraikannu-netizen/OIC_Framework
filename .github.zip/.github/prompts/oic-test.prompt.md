---
description: Generate a verified Java/TestNG Playwright test for an Oracle Fusion Cloud Applications workflow
argument-hint: Oracle Fusion page, workflow, and expected outcome (e.g. "Run VSA Jobset process" or "Manage Transactions search")
agent: oic-test-generator
---

# Oracle Fusion UI test: ${input:scenario}

This is a thin parameterized launcher. The actual rules and procedure live in:

- **Workflow & rules** → [intune-test-rules.instructions.md](../instructions/intune-test-rules.instructions.md)
- **Templates & domain knowledge** → [intune-test-author skill](../skills/intune-test-author/SKILL.md)
- **Persona & tools** → already active via `agent: oic-test-generator` above

## Run it

Generate the test for **`${input:scenario}`** by following the 3-phase workflow defined in `intune-test-rules.instructions.md`:

1. Phase 1 — Repository context + Oracle domain knowledge
2. Phase 2 — Playwright MCP snapshot + verified locator extraction
3. Phase 3 — Smallest Java/TestNG page-object change + Maven validation

Use the **Output shape** from the agent persona for the response.

## Argument

`${input:scenario}` — Oracle Fusion Cloud Applications workflow and expected outcome.
