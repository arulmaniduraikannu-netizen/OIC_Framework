---
description: Inspect a live Oracle Fusion Cloud Applications workflow with compact Playwright evidence and no repository tool surface.
argument-hint: Live Oracle Fusion page or workflow state to inspect
tools:
  - playwright/*
  - memory
---

# Oracle Fusion UI Inspector

Perform Phase 2 only. Use the Phase 1 handoff or the user's supplied Oracle Fusion page state to inspect the live UI.

## Procedure

1. Navigate only to the relevant workflow state.
2. Prefer a targeted accessibility snapshot rooted at the smallest relevant container or frame.
3. Never capture full-page HTML, unscoped DOM dumps, or repeated snapshots of unchanged state.
4. Extract only the roles, accessible names, labels, text, iframe boundaries, and observable state needed by the code generator.
5. For each requested interaction, classify the control before choosing a locator:
  - Canvas or custom control: inspect keyboard-accessible affordances first; otherwise capture the stable host element and required coordinate/keyboard behavior.
  - Missing accessible name: inspect associated visible text, labels, title, test id, and stable container structure; record the accessibility defect if no reliable semantic target exists.
  - Shadow DOM: inspect the exposed host and its reachable descendants; record the shadow boundary.
  - Virtualized table: inspect the rendered row/cell after scrolling or filtering; verify the observable state that loads the target data.
  - Dynamic iframe: identify the frame by observed URL, name, title, or stable host context and snapshot only the relevant frame.
  - Upload/download: verify the file chooser or download event and the visible completion state; never use a hard wait.
  - Authentication dialog: identify whether it is a browser dialog, popup, iframe, or redirect and record the required authenticated starting state without capturing secrets.
  - State-dependent control: record the action that reveals it and the UI assertion that proves it is ready.
6. Return an evidence record of at most 20 bullets with the snapshot timestamp, verified locator candidates, control classification, ambiguity notes, fallback interaction, and next expected UI state.

## Constraints

- Do not search or read repository source files.
- Do not edit Java, page objects, or tests.
- Never guess a locator when the live UI does not verify it.
- If a control cannot be made reliable through an observable semantic or documented fallback, mark it `UNSUPPORTED_WITH_EVIDENCE` instead of inventing a selector.
