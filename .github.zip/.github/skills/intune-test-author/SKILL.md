---
name: intune-test-author
description: Domain knowledge package for authoring Java/TestNG/Playwright automation for Oracle OIC workflows. Includes repository conventions, base-class guidance, and Playwright reliability rules.
---

# Oracle OIC Test Author skill

Portable domain knowledge for generating verified Java/TestNG Playwright tests against
Oracle Fusion Cloud Applications.

## When to invoke this skill

Trigger phrases:
- "Oracle OIC workflow", "Oracle Fusion test"
- "add a Playwright test", "create a page object for Oracle OIC"
- "Run VSA Jobset", "Manage Transactions", "Incentive Compensation"
- "automate Oracle Fusion <feature>"

## Required tools

- `playwright/browser_navigate` + `browser_snapshot` — live UI verification
- `editFiles` — create or update page objects and test classes
- `runCommands` — Maven compile + targeted test run

## Standard project layout

```
src/
├── main/java/com/oracle/oic/
│   ├── base/          BasePage.java, PlaywrightFactory.java
│   ├── pages/         LoginPage.java, HomePage.java, <Feature>Page.java
│   └── utils/         ConfigReader.java, ExcelReader.java
└── test/java/com/oracle/oic/
    ├── base/          BaseTest.java
    └── tests/         <Feature>Test.java
```

## Procedure

The full workflow lives in
[intune-test-rules.instructions.md](../../instructions/intune-test-rules.instructions.md).
This skill **provides the artifacts** the workflow consumes; it does not redefine
the workflow.

Quick recap (authoritative version is in the instructions file):
1. Read `.github/intune-knowledge.md` for cached verified entries
2. Phase 1 — Repository context + Oracle domain knowledge
3. Phase 2 — Playwright MCP snapshot + cite timestamp
4. Phase 3 — Implement smallest page-object or test change using existing base classes
5. Run `mvn -q -DskipTests compile` then the narrowest Maven test filter
6. Append verified findings to `.github/intune-knowledge.md`

## Reusable base-class conventions

- All page objects extend `BasePage` — use `getByRole`, `getByLabel`, `click`, `fill`, `waitForVisible`
- All tests extend `BaseTest` — Playwright lifecycle handled; access page via `getPage()`
- Config values come from `ConfigReader` — never hard-code URLs, credentials, or timeouts
- `PlaywrightFactory` manages browser and context; do not instantiate it directly in tests

## Common Oracle Fusion workflows (cached references)

| Feature | Entry path |
|---|---|
| Manage Transactions | Navigator → Incentive Compensation → Credits and Earnings → Tasks → Manage Transactions |
| Manage Jobsets | Navigator → Incentive Compensation → Processes → Manage Jobsets |
| Run Processes | Navigator → Incentive Compensation → Processes → Run Processes |

> Always verify the current menu path with a Playwright MCP snapshot before writing code.

## Anti-patterns to refuse

- Generating locators without a Playwright MCP snapshot
- Hardcoding XPath or CSS as the primary locator
- Skipping `BasePage` helpers to write inline page interactions in tests
- Using `Thread.sleep`, `page.waitForTimeout`, or any hard wait
- Hard-coding `baseUrl`, credentials, or timeouts inside test or page-object files
