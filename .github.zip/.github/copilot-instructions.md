# Oracle OIC automation workspace

Java, TestNG, Maven, and Playwright automation for Oracle OIC. Page objects and shared browser code live in `src/main/java`; tests live in `src/test/java`.

For new automation, use `oic-domain-research` → `oic-ui-inspector` → `oic-code-generator`. Pass compact handoffs, not chat histories. Phase 2 uses Playwright MCP and is required before adding or changing a locator. No Oracle MCP server is configured.

Follow scoped instruction files for locator, flakiness, verification, domain, and Git rules. Reuse base classes, externalize environment data, avoid hard waits and brittle primary CSS/XPath locators, and never expose secrets.
